// Local headers
#include "program.hpp"
#include "gloom/gloom.hpp"
#include "gloom/shader.hpp"
#include "sphere.hpp"

//#include <math.h>

#include "../vendor/glm/glm/mat4x4.hpp"
#include "../vendor/glm/glm/gtc/type_ptr.hpp"
#include "../vendor/glm/glm/gtx/transform.hpp"
#include "../vendor/glm/glm/vec3.hpp"
#include "../vendor/glm/glm/gtc/matrix_transform.hpp"

//#include <cstdlib>

#include <stack>

// Global variables for keypresses
float horizontal = 0.0;
float vertical = 0.0;
float forward = 1.0;
float horizontal_rot = 0.0;
float vertical_rot = 0.0;


void calculateTransformation(SceneNode* current, float t){
    glm::vec3 pos = glm::vec3(current->x, current->y, current->z);
    glm::mat4x4 translation = glm::translate(pos);
    glm::mat4x4 rotation = glm::rotate(current->rotationSpeedRadians*t, current->rotationDirection);
    current->currentTransformationMatrix = rotation * translation;

    /*glm::vec4 old_pos = glm::vec4(current->x, current->y, current->z, 1);

    glm::vec3 new_pos = current->currentTransformationMatrix * old_pos;
    current->x = new_pos[0];
    current->y = new_pos[1];
    current->z = new_pos[2];*/
}

void updateSolarSystem(SceneNode* sun){
    float t = getTimeDeltaSeconds();
    std::stack<SceneNode*> s;
    s.push(sun);

    SceneNode* currentNode;

    while(!s.empty()){
        currentNode = s.top();
        if(currentNode->visited){
            s.pop();
            continue;
        }
        printNode(currentNode);
        //printNode(currentNode->children[4]);
        if(currentNode->children.size() == 0){
            calculateTransformation(currentNode, t);
            s.pop();
        }else{
            for(int i = 0 ; i < currentNode->children.size(); i++){
                s.push(currentNode->children[i]);   
            }
        }
        currentNode->visited = 1;
    }
}

SceneNode* createSolarSystem(){
    // SUN
    unsigned int sunVAO = createCircleVAO(25, 25, 1);
    SceneNode* sun = createSceneNode();
    sun->vertexArrayObjectID = sunVAO;
    sun->scaleFactor = 1;
    sun->rotationSpeedRadians = 0;
    sun->rotationDirection = glm::vec3(0,1,0);
    sun->name = "Sun";

    // MERCURY
    unsigned int mercuryVAO = createCircleVAO(25, 25, 1);
    SceneNode* mercury = createSceneNode();
    mercury->vertexArrayObjectID = mercuryVAO;
    mercury->scaleFactor = 0.666;
    mercury->rotationSpeedRadians = 5;
    mercury->rotationDirection = glm::vec3(0,1,0);
    mercury->name = "Mercury";
    mercury->x = 3;

    // MARS    
    unsigned int marsVAO = createCircleVAO(25, 25, 1);
    SceneNode* mars = createSceneNode();
    mars->vertexArrayObjectID = marsVAO;
    mars->scaleFactor = 0.7;
    mars->rotationSpeedRadians = 3;
    mars->rotationDirection = glm::vec3(0,1,0);
    mars->name = "Mars";
    mars->x = 6;

    // MARS MOON
    unsigned int marsMoonVAO = createCircleVAO(25, 25, 1);
    SceneNode* marsMoon = createSceneNode();
    marsMoon->vertexArrayObjectID = marsMoonVAO;
    marsMoon->scaleFactor = 0.15;
    marsMoon->rotationSpeedRadians = 15;
    marsMoon->rotationDirection = glm::vec3(0,1,0);
    marsMoon->name = "Mars's moon";
    marsMoon->x = 1;

    // JUPITER
    unsigned int jupiterVAO = createCircleVAO(25, 25, 1);
    SceneNode* jupiter = createSceneNode();
    jupiter->vertexArrayObjectID = jupiterVAO;
    jupiter->scaleFactor = 0.4;
    jupiter->rotationSpeedRadians = 8;
    jupiter->rotationDirection = glm::vec3(0,-1,0);
    jupiter->name = "Jupiter";
    jupiter->x = 9;    


    // EARTH
    unsigned int earthVAO = createCircleVAO(25, 25, 1);
    SceneNode* earth = createSceneNode();
    earth->vertexArrayObjectID = earthVAO;
    earth->scaleFactor = 0.5;
    earth->rotationSpeedRadians = 2;
    earth->rotationDirection = glm::vec3(0,1,0);
    earth->name = "Earth";
    earth->x = 12;

    // EARTH MOON
    unsigned int earthMoonVAO = createCircleVAO(25, 25, 1);
    SceneNode* earthMoon = createSceneNode();
    earthMoon->vertexArrayObjectID = earthMoonVAO;
    earthMoon->scaleFactor = 0.3;
    earthMoon->rotationSpeedRadians = 5;
    earthMoon->rotationDirection = glm::vec3(0,1,0);
    earthMoon->name = "Earth's moon";
    earthMoon->x = 2;

    // VENUS
    unsigned int venusVAO = createCircleVAO(25, 25, 1);
    SceneNode* venus = createSceneNode();
    venus->vertexArrayObjectID = venusVAO;
    venus->scaleFactor = 0.9;
    venus->rotationSpeedRadians = 8;
    venus->rotationDirection = glm::vec3(0,-1,0);
    venus->name = "Venus";
    venus->x = 15;

    // Add kids to sun
    addChild(sun, mercury);
    addChild(sun, mars);
    addChild(sun, jupiter);
    addChild(sun, earth);
    addChild(sun, venus);

    // Add moons to planets
    addChild(earth, earthMoon);
    addChild(mars, marsMoon);

    return sun;
}

GLuint set_vao(float* coord, GLuint* indices, float* colors, int arrayLength){
	// Create and bind VAO
	GLuint array = 0;
	glGenVertexArrays(1, &array);
	glBindVertexArray(array);

	// Create and bind VBO
	uint buffer = 0;
	glGenBuffers(1, &buffer);
	glBindBuffer(GL_ARRAY_BUFFER, buffer);

	// Put data to VBO
	glBufferData(GL_ARRAY_BUFFER, arrayLength * sizeof(float), coord, GL_STATIC_DRAW);

	// Set vertex attributes
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);

	// Enable VBO
	glEnableVertexAttribArray(0);

	// Create and bind index VBO
	uint index_buffer = 0;
	glGenBuffers(1, &index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);

	// Fill index buffer
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, (arrayLength/3)*sizeof(GLuint), indices, GL_STATIC_DRAW);

	// Create and bind color VBO
	uint color_buffer = 0;
	glGenBuffers(1, &color_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, color_buffer);

	// Fill color buffer
	glBufferData(GL_ARRAY_BUFFER, (arrayLength/3)*4*sizeof(GLuint), colors, GL_STATIC_DRAW);

	// Set vertex attributes
	glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(1);

	printGLError();

	return array;
}


void runProgram(GLFWwindow* window)
{
    // Set GLFW callback mechanism(s)
    glfwSetKeyCallback(window, keyboardCallback);
	
    // Enable depth (Z) buffer (accept "closest" fragment)
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    // Configure miscellaneous OpenGL settings
    glEnable(GL_CULL_FACE);

    // Set default colour after clearing the colour buffer
    glClearColor(0.3f, 0.3f, 0.4f, 1.0f);

    // Set up your scene here (create Vertex Array Objects, etc.)
	Gloom::Shader shader;
	shader.makeBasicShader("/home/shomeb/a/andreanv/Documents/psychic-garbanzo/graphics/ass3/gloom/gloom/shaders/simple.vert",
						   "/home/shomeb/a/andreanv/Documents/psychic-garbanzo/graphics/ass3/gloom/gloom/shaders/simple.frag");
	shader.link();

    SceneNode* sun = createSolarSystem();

    //printNode(sun);

    updateSolarSystem(sun);
	glm::mat4x4 trans_mat(1.0f);

    unsigned int circle = createCircleVAO(10, 10, 0.5);

    // Rendering Loop
    while (!glfwWindowShouldClose(window))
    {
        // Clear colour and depth buffers
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		// Calculate rotation matrices
		glm::mat4x4 rotation_y = glm::rotate(horizontal_rot, glm::vec3(0,1,0));
		glm::mat4x4 rotation_x = glm::rotate(vertical_rot, glm::vec3(1,0,0));		
		glm::mat4x4 translation = glm::translate(glm::vec3(-horizontal, -vertical, forward));
		
		glm::mat4x4 projection = glm::perspective(glm::radians(90.0),
												  4.0 / 3.0,
												  1.0, 100.0);

		trans_mat = projection*translation*rotation_x*rotation_y;

        //glm::mat4x4 trans_mat = glm::scale(glm::vec3(0.5, 0.5, 0.5));

		// Draw your scene here
		shader.activate();

		glUniformMatrix4fv(3, 1, GL_FALSE, glm::value_ptr(trans_mat));

        glBindVertexArray(circle);
        glDrawElements(GL_TRIANGLES, 200*3*3, GL_UNSIGNED_INT, 0);
        printGLError();
    

		shader.deactivate();

        // Handle other events
        glfwPollEvents();

        // Flip buffers
        glfwSwapBuffers(window);
    }
}


void keyboardCallback(GLFWwindow* window, int key, int scancode,
                      int action, int mods)
{
    // Use escape key for terminating the GLFW window
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS){
        glfwSetWindowShouldClose(window, GL_TRUE);

    } if (key == GLFW_KEY_W){// && action == GLFW_PRESS){
		forward += 0.1;
	} if (key == GLFW_KEY_S){// && action == GLFW_PRESS){
		forward -= 0.1;
	} if (key == GLFW_KEY_A){// && action == GLFW_PRESS){
		horizontal -= 1.0;
	} if (key == GLFW_KEY_D){// && action == GLFW_PRESS){
		horizontal += 1.0;
	} if (key == GLFW_KEY_UP){// && action == GLFW_PRESS){
		vertical_rot -= 0.1;
	} if (key == GLFW_KEY_DOWN){// && action == GLFW_PRESS){
		vertical_rot += 0.1;
	} if (key == GLFW_KEY_LEFT){// && action == GLFW_PRESS){
		horizontal_rot -= 0.1;
	} if (key == GLFW_KEY_RIGHT){// && action == GLFW_PRESS){
		horizontal_rot += 0.1;
	} if (key == GLFW_KEY_Q){// && action == GLFW_PRESS){
		vertical += 1.0;
	}if (key == GLFW_KEY_E){// && action == GLFW_PRESS){
		vertical -= 1.0;
	}
}
