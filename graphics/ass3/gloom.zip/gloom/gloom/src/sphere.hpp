#pragma once

#include <math.h>
#include "sceneGraph.hpp"
#include "program.hpp"

unsigned int createCircleVAO(unsigned int slices, unsigned int layers, float* color);
