// Local headers
#include "program.hpp"
#include "gloom/gloom.hpp"
#include "gloom/shader.hpp"

#include <stdio.h>

GLuint set_vao(float* coord, GLuint* indices, int arrayLength){
	// Create and bind VAO
	GLuint array = 0;
	glGenVertexArrays(1, &array);
	glBindVertexArray(array);

	// Create and bind VBO
	uint buffer = 0;
	glGenBuffers(1, &buffer);
	glBindBuffer(GL_ARRAY_BUFFER, buffer);

	// Put data to VBO
	glBufferData(GL_ARRAY_BUFFER, arrayLength * sizeof(float), coord, GL_STATIC_DRAW);

	// Set vertex attributes
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);

	// Enable VBO
	glEnableVertexAttribArray(0);

	// Create and bind index VBO
	uint index_buffer = 0;
	glGenBuffers(1, &index_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);

	// Fill index buffer
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, (arrayLength/3)*sizeof(GLuint), indices, GL_STATIC_DRAW);

	printGLError();

	return array;
}


void runProgram(GLFWwindow* window)
{
	// Set GLFW callback mechanism(s)
    glfwSetKeyCallback(window, keyboardCallback);
   	// Enable depth (Z) buffer (accept "closest" fragment)
	glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    // Configure miscellaneous OpenGL settings
	glEnable(GL_CULL_FACE);

	// Set default colour after clearing the colour buffer
	glClearColor(0.3f, 0.3f, 0.4f, 1.0f);

	// Set up your scene here (create Vertex Array Objects, etc.)
	Gloom::Shader shader;
	shader.makeBasicShader("/home/shomeb/a/andreanv/Documents/psychic-garbanzo/graphics/ass1/gloom/gloom/shaders/simple.vert",
						   "/home/shomeb/a/andreanv/Documents/psychic-garbanzo/graphics/ass1/gloom/gloom/shaders/simple.frag");
	shader.link();

	/* TASK 1b */
	/*float triangle_coord[] = {0.0, -0.6, 0.0, 0.6, -0.6, 0.0, 0.0, 0.6, 0.0,
				  			 -0.9, 0.9, 0.0, -0.3, 0.7, 0.0, -0.3, 0.9, 0.0,
				  			 0.9, 0.9, 0.0, 0.9, 0.7, 0.0, 0.6, 0.9, 0.0,
				  			 0.6, -0.9, 0.0, 0.9, -0.9, 0.0, 0.9, -0.6, 0.0,
							 -0.8, 0.0, 0.0, -0.2, 0.1, 0.0, -0.5, 0.2, 0.0};
	GLuint triangle_idx[] = {0, 1, 2, 3, 4, 5, 7, 6, 8, 9, 10, 11, 12, 13, 14};
	GLuint triangleOne = 0;
	triangleOne = set_vao(triangle_coord, triangle_idx, 45);*/

	/* TASK 1c */
	/*float triangle_coord[] = {0.6, -0.8, -1.2, 0.0, 0.4, 0.0, -0.8, -0.2, 1.2};
	GLuint triangle_idx[] = {0, 1, 2};
	GLuint triangle = 0;
	triangle = set_vao(triangle_coord, triangle_idx, 9);*/

	float triangle_coord[] = {0.0, 0.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.5, 0.0};
	GLuint triangle_idx[] = {0, 1, 2};
	GLuint triangle = 0;
	triangle = set_vao(triangle_coord, triangle_idx, 9);

    // Rendering Loop
	while (!glfwWindowShouldClose(window))
   	{
		// Clear colour and depth buffers
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

       	// Draw your scene here
		shader.activate();
		
		/* TASK 1b */
		/*glBindVertexArray(triangleOne);
		glDrawElements(GL_TRIANGLES, 15, GL_UNSIGNED_INT, 0);
		printGLError();
		glBindVertexArray(0);*/

		/* TASK 1c & 2b */
		glBindVertexArray(triangle);
		glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, 0);
		printGLError();
		glBindVertexArray(0);

		shader.deactivate();
        
		// Handle other events
        glfwPollEvents();

        // Flip buffers
        glfwSwapBuffers(window);
	}

	shader.destroy();
}


void keyboardCallback(GLFWwindow* window, int key, int scancode,
                      int action, int mods)
{
    // Use escape key for terminating the GLFW window
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }
}

